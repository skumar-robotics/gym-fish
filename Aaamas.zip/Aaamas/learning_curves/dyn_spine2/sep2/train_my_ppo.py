import os, csv
from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import CheckpointCallback, EvalCallback
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.vec_env import SubprocVecEnv
import gym, gym_fish
from gym.wrappers import TimeLimit
from PIL import Image
import matplotlib
import matplotlib.pyplot as plt
import numpy as np

matplotlib.use("Agg")

# Maximum length of episode
max_eps_steps = 1200

class EpisodeLogger(gym.Wrapper):
    def __init__(self, env):
        super(EpisodeLogger, self).__init__(env)
        self.current_step = 0
        self.episode_count = 0
        self.current_episode_reward = 0
        self.max_eps_steps = max_eps_steps
        self.log_file = "monitor.csv"
        self.best_reward = -float("inf")  # For tracking the best reward

        # Initialize the log file
        with open(self.log_file, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(
                ["Episode", "Cum Reward", "Steps", "Best Reward"]
            )  # Adding information

    def step(self, action):
        self.current_step += 1
        obs, reward, done, info = self.env.step(action)
        self.current_episode_reward += reward

        if done or self.current_step >= self.max_eps_steps:
            if self.current_episode_reward > self.best_reward:
                self.best_reward = self.current_episode_reward  # Update best reward

            with open(self.log_file, mode="a", newline="") as file:
                writer = csv.writer(file)
                cumm_reward = self.current_episode_reward
                writer.writerow(
                    [
                        self.episode_count,
                        cumm_reward,
                        self.current_step,
                        self.best_reward,
                    ]
                )  # Added best reward

            print(
                f"Episode {self.episode_count}: Cum Reward {cumm_reward}, Steps {self.current_step}, Best Cum Reward {self.best_reward}"
            )  # Added best reward

            self.episode_count += 1
            self.current_step = 0
            self.current_episode_reward = 0

        return obs, reward, done, info

def make_env():
    def _init():
        env = gym.make("koi-cruising-v0", gpuId=0)
        env.reset()
        env = TimeLimit(env, max_episode_steps=max_eps_steps)
        env = Monitor(env)
        env = EpisodeLogger(env)
        return env
    return _init

if __name__ == "__main__":
    # Create a list of environments
    envs = [make_env() for _ in range(4)]

    # Create the SubprocVecEnv with 4 environments
    env = SubprocVecEnv(envs)

    # Create the PPO model
    model = PPO(
        "MlpPolicy",
        env,
        n_steps=max_eps_steps,
        batch_size=8,
        n_epochs=10,
        gamma=0.99,
        ent_coef=0.01,
        vf_coef=0.5,
        verbose=1,
    )

    # Create the callbacks
    checkpoint_callback = CheckpointCallback(
        save_freq=4 * max_eps_steps, save_path="./models/", name_prefix="dyn_ppo_spine2"
    )
    eval_callback = EvalCallback(
        env,
        best_model_save_path="./",
        log_path="./",
        eval_freq=5 * max_eps_steps,
        deterministic=True,
        render=False,
    )

    # Train the model (10 million steps)
    model.learn(total_timesteps=10000000, callback=[checkpoint_callback, eval_callback])

