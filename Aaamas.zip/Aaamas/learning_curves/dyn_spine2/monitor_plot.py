import matplotlib.pyplot as plt
import matplotlib
# matplotlib.use("Agg")

import numpy as np
import pandas as pd
from statsmodels.nonparametric.smoothers_lowess import lowess

# Load the data from the CSV files
file_path1 = 'monitor_1.csv'
df1 = pd.read_csv(file_path1)
# Keep rows where Episode <= 91
df1 = df1[df1["Episode"] <= 6]

file_path2 = 'monitor_2.csv'
df2 = pd.read_csv(file_path2)
# Keep rows where Episode <= 44
df2 = df2[df2["Episode"] <= 11]
# Adjust the Episode numbers in df2 to start from 92
df2['Episode'] = df2['Episode'] + 6

file_path3 = 'monitor_3.csv'
df3 = pd.read_csv(file_path3)
# Keep rows where Episode <= 44
df3 = df3[df3["Episode"] <= 100]
# Adjust the Episode numbers in df2 to start from 92
df3['Episode'] = df3['Episode'] + 17





# Concatenate the two DataFrames
df_combined = pd.concat([df1, df2,df3], ignore_index=True)

# Display the combined DataFrame
# print(df_combined)
df=df_combined
print(df)
# df.to_csv('combined_monitr.csv', index=True)
# # Plot Episode vs Cum Reward
plt.figure(figsize=(10, 6))

plt.scatter(df['Episode'], df['Cum Reward'], marker='o', linestyle='-', color='b', alpha=0.3, label="Actual Reward")

# Smoothing and bootstrap processing
x = df['Episode']
y = df['Cum Reward']
# print(x)
# Number of bootstrap samples
n_bootstraps = 100

# Storage for bootstrapped smoothed curves
smoothed_bootstraps = []

# Generate bootstrapped smoothed curves
for _ in range(n_bootstraps):
    indices = np.random.choice(len(x), len(x), replace=True)
    bootstrap_x = x[indices]
    bootstrap_y = y[indices]
    smoothed = lowess(bootstrap_y, bootstrap_x, frac=0.3)
    smoothed_bootstraps.append(smoothed)

# Extract smoothed values from bootstraps
smoothed_x = np.mean([sb[:, 0] for sb in smoothed_bootstraps], axis=0)
smoothed_y_mean = np.mean([sb[:, 1] for sb in smoothed_bootstraps], axis=0)

# Calculate 95% confidence interval
smoothed_y_bootstraps = np.array([sb[:, 1] for sb in smoothed_bootstraps])
ci_lower = np.percentile(smoothed_y_bootstraps, 2.5, axis=0)
ci_upper = np.percentile(smoothed_y_bootstraps, 97.5, axis=0)

# Plot smoothed line
plt.plot(smoothed_x, smoothed_y_mean, color="red", label="Smoothed Learning Curve")

# Plot shaded region for confidence interval
plt.fill_between(smoothed_x, ci_lower, ci_upper, color="red", alpha=0.3, label="95% Confidence Interval")

plt.xlabel("Episode")
plt.ylabel("Cumulative Reward")
plt.title("sp2 dyn Episode vs Cumulative Reward with Smoothing")
plt.grid(True)
plt.legend()
plt.show()
# Save the plot
# plt.savefig("path_sp2_dyn.png")
# 
