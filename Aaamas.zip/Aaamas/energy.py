import re

# Path to your file
file_path = 'spine3_energy.txt'

# Initialize the sum for action_reward
action_reward_sum = 0

# Regular expression pattern to find the action_reward values
pattern = r"'action_reward': ([\-\d\.]+)"

# Read the file and extract action_reward values
with open(file_path, 'r') as file:
    for line in file:
        match = re.search(pattern, line)
        print(match)
        if match:
            action_reward_sum += float(match.group(1))

print("Total sum of action_reward:", action_reward_sum)
