#!/bin/bash

for i in {1..10}
do
   echo "Running test_model.py - Iteration $i"
   python test_model2.py
done

echo "All 10 iterations completed."

