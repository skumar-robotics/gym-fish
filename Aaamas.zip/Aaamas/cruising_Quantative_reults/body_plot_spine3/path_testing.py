import numpy as np
import matplotlib.pyplot as plt

# Read the data from the file
# file_path = 'spine2_best/best_path_square_body.txt'  # Replace with your file path
file_path="./dummy/10_body_xyz_values.txt"
file_path1="./dummy/10_goal_pos.txt"


data = []

with open(file_path, 'r') as file:
    for line in file:
        # Convert the string line to a list of floats
        values = list(map(float, line.strip('[] \n').split()))
        data.append(values)

# Convert data to numpy array for easy indexing
data = np.array(data)

# Extract x and z columns
x_values = data[:, 0]  # First column
z_values = data[:, 2]  # Third column

# Plotting
plt.figure(figsize=(10, 6))

plt.plot(x_values, z_values, marker='o', linestyle='-', color='b', label='Body pose')




data = []

with open(file_path1, 'r') as file:
    for line in file:
        # Convert the string line to a list of floats
        values = list(map(float, line.strip('[] \n').split()))
        data.append(values)

# Convert data to numpy array for easy indexing
data = np.array(data)

# Extract x and z columns
x_values = data[:, 0]  # First column
z_values = data[:, 2]  # Third column

# Plotting

plt.plot(x_values, z_values, marker='o', linestyle='-', color='r', label='Goal Pos')

plt.title('Plot of x vs z from .txt File')
plt.xlabel('x (First Column)')
plt.ylabel('z (Third Column)')
plt.legend()
plt.grid(True)






plt.title('Plot of x vs z from .txt File')
plt.xlabel('x (First Column)')
plt.ylabel('z (Third Column)')
plt.legend()
plt.grid(True)











plt.savefig("body_xyz_spine2.png")
# # plt.show()
# python3 path_testing.py koi-path-v0.zip 4_joint_best_model_69_body.txt 4_joint_best_model_69_goal.txt path_69
  
# python3 path_testing.py koi-path-v0.zip 4_joint_best_model_s_curve_body.txt 4_joint_best_model_s_curve_goal.txt path_s_curve

# python3 path_testing.py koi-path-v0.zip 4_joint_best_model_square_body.txt 4_joint_best_model_square_goal.txt path_square

# python3 path_testing.py koi-path-v0.zip 4_joint_best_model_ss_body.txt 4_joint_best_model_ss_goal.txt path_ss

# python3 path_testing.py koi-path-v0.zip 4_joint_best_model_sin_body.txt 4_joint_best_model_sin_goal.txt sin

# python3 path_testing.py koi-path-v0.zip 4_joint_best_model_tri_body.txt 4_joint_best_model_tri_goal.txt tri

# ~                                                                                                                        