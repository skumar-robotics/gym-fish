import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from statsmodels.nonparametric.smoothers_lowess import lowess

# List of file paths and colors for each plot
file_paths = ['dyn_spine2/learning.csv', 'dyn_spine3/learning.csv']
colors = ['blue', 'red']
labels = ['Spine 2', 'Spine 3']

# Number of bootstrap samples
n_bootstraps = 100

# Loop through each file and plot
for i, file_path in enumerate(file_paths):
    # Load the data
    file_data = pd.read_csv(file_path)
    data = file_data[file_data['Episode'] < 100]

    x = data['Episode'].to_numpy()  # Convert to NumPy array
    y = data['Cum Reward'].to_numpy()  # Convert to NumPy array

    # Storage for bootstrapped smoothed curves
    smoothed_bootstraps = []

    # Generate bootstrapped smoothed curves
    for _ in range(n_bootstraps):
        indices = np.random.choice(len(x), len(x), replace=True)
        bootstrap_x = x[indices]
        bootstrap_y = y[indices]
        smoothed = lowess(bootstrap_y, bootstrap_x, frac=0.3)
        smoothed_bootstraps.append(smoothed)

    # Extract smoothed values from bootstraps
    smoothed_x = np.mean([sb[:, 0] for sb in smoothed_bootstraps], axis=0)
    smoothed_y_mean = np.mean([sb[:, 1] for sb in smoothed_bootstraps], axis=0)

    # Calculate 95% confidence interval
    smoothed_y_bootstraps = np.array([sb[:, 1] for sb in smoothed_bootstraps])
    ci_lower = np.percentile(smoothed_y_bootstraps, 2.5, axis=0)
    ci_upper = np.percentile(smoothed_y_bootstraps, 97.5, axis=0)

    # Plot smoothed line
    plt.plot(smoothed_x, smoothed_y_mean, color=colors[i], label=f"{labels[i]} Smoothed Curve")

    # Plot shaded region for confidence interval
    plt.fill_between(smoothed_x, ci_lower, ci_upper, color=colors[i], alpha=0.3, label=f"{labels[i]} 95% CI")

# Add labels, title, grid, and legend
plt.xlabel("Episode")
plt.ylabel("Cumulative Reward")
plt.title("Episode vs Cumulative Reward with Smoothing for Different Spine for Cruising task")
plt.grid(True)
plt.legend()

# Show the plot or save it
plt.show()
# plt.savefig("multi_path_smoothed.png")

