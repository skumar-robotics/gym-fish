import pandas as pd

# Load the CSV file (replace 'path_to_your_file.csv' with your actual file path)
file_path = 'dyn_spine2/new_spine2_testing/monitor.csv'

# Read the CSV file
df = pd.read_csv(file_path)

# Calculate the sum of the 'Steps' column
sum_of_steps = df['Steps'].sum()

# Print the result
print(f"The sum of the 'Steps' column is: {sum_of_steps}")

