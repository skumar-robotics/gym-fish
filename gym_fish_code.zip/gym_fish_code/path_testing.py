
import os
import gym
import gym_fish
from stable_baselines3 import SAC
import numpy as np
from PIL import Image

gpuId = 0
env = gym.make('koi-cruising-v0', gpuId=gpuId)
env.render_mode = "rgb_array"
    
model=SAC.load("koi-path-v0")

trajectory_file  = os.path.dirname(gym_fish.__file__)+ '/assets/trajectory/path_69.json'
from gym_fish.envs.py_util import flare_util
from gym_fish.envs.entities.trajectory import trajectory
### test generalization to sequence goals
path_data = flare_util.path_data()
path_data.from_json(trajectory_file)
path_traj = trajectory(path_data)
env.reset()
t = 0.001
dt = 0.05
env.goal_pos = path_traj.get_pose(t+dt).position
env.path_dir = (env.goal_pos-env.body_xyz)/np.linalg.norm((env.goal_pos-env.body_xyz))
env.max_time = 30
i=0
while path_traj.parameterize(env.body_xyz[0],env.body_xyz[1],env.body_xyz[2])<0.98:
    obs = env._get_obs()
    action,_ = model.predict(obs, deterministic=True)
    env.step(action)
    arr=env.render()
    image = Image.fromarray(arr)

    # Then a scene output image can be viewed in 
    image.save('output/output{i}.png'.format(i=i))
    i+=1
    print(i)
    print(np.linalg.norm(env.body_xyz-env.goal_pos))
    print("goal_pos",env.goal_pos,"body_xyz",env.body_xyz)
    

    # set next target, if close to current target 
    if np.linalg.norm(env.body_xyz-env.goal_pos)<0.25:
        t = t+dt        
        env.goal_pos = path_traj.get_pose(t+dt).position
        env.path_dir = (env.goal_pos-env.body_xyz)/np.linalg.norm((env.goal_pos-env.body_xyz))



python3 path_testing.py best_model.zip best_body_values_path_69.txt best_goal_values_path_69.txt path_69

python3 path_testing.py best_model.zip best_body_values_path_s.txt best_goal_values_path_s.txt path_s_curve

python3 path_testing.py best_model.zip best_body_values_path_square.txt best_goal_values_path_square.txt path_square

python3 path_testing.py best_model.zip best_body_values_path_ss_curve.txt best_goal_values_path_s_curve.txt path_ss

python3 path_testing.py best_model.zip best_body_values_path_sin.txt best_goal_values_path_sin.txt sin

python3 path_testing.py best_model.zip best_body_values_path_tri.txt best_goal_values_path_tri.txt tri


