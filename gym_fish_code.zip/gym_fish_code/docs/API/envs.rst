Environments
==================

.. automodule:: gym_fish.envs.coupled_env
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: gym_fish.envs.fish_env_basic
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: gym_fish.envs.fish_env_path_basic
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: gym_fish.envs.fish_env_pose_control
   :members:
   :undoc-members:
   :show-inheritance:

.. automodule:: gym_fish.envs.fish_env_schooling
   :members:
   :undoc-members:
   :show-inheritance:
~
~


