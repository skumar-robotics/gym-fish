Under Water agents
=============================

.. automodule:: gym_fish.envs.entities.underwater_agent
   :members:
   :undoc-members:
   :show-inheritance:

