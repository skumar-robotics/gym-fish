import vtk
import os

# Input directory containing .vtk files and output directory for .png files
input_dir = 'Objects'
output_dir = 'output'

# Ensure the output directory exists
os.makedirs(output_dir, exist_ok=True)

# Loop through each .vtk file in the input directory
for filename in os.listdir(input_dir):
    if filename.endswith(".vtk"):
        file_path = os.path.join(input_dir, filename)
        output_image_path = os.path.join(output_dir, f"{os.path.splitext(filename)[0]}.png")

        # Step 1: Create a reader for the .vtk file
        reader = vtk.vtkPolyDataReader()
        reader.SetFileName(file_path)
        reader.Update()

        # Step 2: Create a mapper for the polydata
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(reader.GetOutputPort())

        # Step 3: Create an actor for the mesh and set wireframe mode
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        actor.GetProperty().SetColor(0.9, 0.9, 0.9)  # Light gray color
        actor.GetProperty().SetRepresentationToWireframe()

        # Step 4: Create renderer and render window (no interactor needed)
        renderer = vtk.vtkRenderer()
        render_window = vtk.vtkRenderWindow()
        render_window.AddRenderer(renderer)
        render_window.SetSize(1080, 720)  # Set the render window size to 600x600

        render_window.SetOffScreenRendering(1)  # Enable off-screen rendering

        # Add the actor to the renderer and set background color
        renderer.AddActor(actor)
        renderer.SetBackground(0.1, 0.1, 0.1)  # Dark background for contrast

        # Step 5: Render the window
        render_window.Render()

        # Step 6: Capture the render window as an image
        window_to_image_filter = vtk.vtkWindowToImageFilter()
        window_to_image_filter.SetInput(render_window)
        window_to_image_filter.Update()

        # Step 7: Write the captured image to a PNG file
        png_writer = vtk.vtkPNGWriter()
        png_writer.SetFileName(output_image_path)
        png_writer.SetInputConnection(window_to_image_filter.GetOutputPort())
        png_writer.Write()

        print(f"Saved: {output_image_path}")

print("All files processed and saved as PNGs.")



