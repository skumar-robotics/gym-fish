import gym
import gym_fish

# Our environment runs on GPU to accelerate simulations, ensure a cuda-supported GPU exists on your machine
gpuId = 0

for i in range(5):

    env = gym.make('koi-cruising-v0', gpuId=gpuId)
    env.render_mode = "rgb_array"
    action = env.action_space.sample()
    obs, reward, done, info = env.step(action)

    print("goal_pos",env.goal_pos,"body_xyz",env.body_xyz,"path_start",env.path_start)
    

