from setuptools import setup

setup(name='gym_fish',
      version='0.0.1',
      install_requires=['gym','moderngl','pyrr','pyopengl','pyside2','pathlib','pyquaternion','stable-baselines3[extra]']  # And any other dependencies foo needs
)
