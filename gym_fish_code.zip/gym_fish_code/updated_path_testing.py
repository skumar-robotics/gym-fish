import os
import gym
import gym_fish
from stable_baselines3 import PPO
import numpy as np
from PIL import Image
import argparse

# Parse command-line arguments
parser = argparse.ArgumentParser(description='Run PPO model with gym environment.')
parser.add_argument('model_name', type=str, help='Path to the PPO model file')
parser.add_argument('body_xyz_file', type=str, help='File name for body_xyz output')
parser.add_argument('goal_pos_file', type=str, help='File name for goal_pos output')
parser.add_argument('traj_path', type=str, help='File name for trajectory')

args = parser.parse_args()

gpuId = 0
env = gym.make('koi-path-v0', gpuId=gpuId)

print(env.action_space.sample())
model = PPO.load(f"models/{args.model_name}", env=env)

trajectory_file  = os.path.dirname(gym_fish.__file__) + '/assets/trajectory/{path}.json'.format(path=args.traj_path)

from gym_fish.envs.py_util import flare_util
from gym_fish.envs.entities.trajectory import trajectory

path_data = flare_util.path_data()
path_data.from_json(trajectory_file)
path_traj = trajectory(path_data)
env.reset()
t = 0.001
dt = 0.05
env.goal_pos = path_traj.get_pose(t + dt).position
env.path_dir = (env.goal_pos - env.body_xyz) / np.linalg.norm((env.goal_pos - env.body_xyz))
env.max_time = 30
i = 0

with open(args.body_xyz_file, 'w') as body_file, open(args.goal_pos_file, 'w') as goal_file,open(f'dist_path_{args.body_xyz_file}','w') as dist_path:
    while path_traj.parameterize(env.body_xyz[0], env.body_xyz[1], env.body_xyz[2]) < 0.98:
        obs = env._get_obs()
        action, _ = model.predict(obs, deterministic=False)
        env.step(action)
        i += 1
        print(i)
        if i > 2000:
            break
        print("error", np.linalg.norm(env.body_xyz - env.goal_pos))
        print("goal_pos", env.goal_pos, "body_xyz", env.body_xyz)
        print("distance", env.dist_to_path)

        dist_path.write(f'{env.dist_to_path}\n')

        body_file.write("{value}\n".format(value=env.body_xyz))
        goal_file.write("{value}\n".format(value=env.goal_pos))

        if np.linalg.norm(env.body_xyz - env.goal_pos) < 0.25:
            t = t + dt
            env.goal_pos = path_traj.get_pose(t + dt).position
            env.path_dir = (env.goal_pos - env.body_xyz) / np.linalg.norm((env.goal_pos - env.body_xyz))
    
    print("outside the loop")
